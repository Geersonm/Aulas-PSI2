using System;

namespace jg2
{
public class JogoView 
{
    public void ApresentarTabuleiro(char[,] tabuleiro)
    {
        
       
        Console.WriteLine($"_{tabuleiro[0,0]}_|_{tabuleiro[0,1]}_|_{tabuleiro[0,2]}_");
        Console.WriteLine($"_{tabuleiro[1,0]}_|_{tabuleiro[1,1]}_|_{tabuleiro[1,2]}_");
        Console.WriteLine($" {tabuleiro[2,0]} | {tabuleiro[2,1]} |{tabuleiro[2,2]}");

    }

    public int PedirJogada()
    {
        Console.WriteLine("Faça a sua Jogada (1-9):");
        int jogada = int.Parse(Console.ReadLine());
        return jogada;
    }

    public void MostrarEstats()
    {
        
        Console.WriteLine("Estatísticas do Jogo:");
        Console.WriteLine($"Total de jogos: {JogoControllertotalJogos}");
        Console.WriteLine($"Número de vitórias do jogador X: {vitoriasJogadorX}");
        Console.WriteLine($"Número de vitórias do jogador O: {vitoriasJogadorO}");
        Console.WriteLine($"Número total de jogadas do jogador X: {totalJogadasJogadorX}");
        Console.WriteLine($"Número total de jogadas do jogador O: {totalJogadasJogadorO}");
        Console.WriteLine($"Número de vezes que o tabuleiro foi totalmente preenchido: {empates}");
    }

     private void CarregarEstatisticas()
    {
        if (File.Exists(caminhoArquivo))
        {
            try
            {
                using (StreamReader sr = new StreamReader(caminhoArquivo))
                {
                    vitoriasJogadorX = int.Parse(sr.ReadLine());
                    vitoriasJogadorO = int.Parse(sr.ReadLine());
                    totalJogadasJogadorX = int.Parse(sr.ReadLine());
                    totalJogadasJogadorO = int.Parse(sr.ReadLine());
                    tabuleiroTotalmentePreenchido = int.Parse(sr.ReadLine());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Erro ao ler arquivo de estatísticas: {e.Message}");
            }
        }
        else
        {
            Console.WriteLine("Arquivo de estatísticas não encontrado. Criando novo arquivo...");
            AtualizarEstatisticas();
        }
    }
 
}
}